// h1 > react element
// h1: Create Element 실습
import * as React from "react";
import { createRoot } from "react-dom/client";
//import * as ReactDom from 'react-dom';

//close tag 필수
// 하나의 최상위 엘리먼트만 가져야한다. > React.Fragment, <>
// {}를 통해 js 표현식을 props로 넘겨줄 수 있다. 
const jsxElement = (
  <React.Fragment>
    <div
      className="test"
      onClick={() => {
        console.log("1");
      }}
    >
      <h1 className="1">hi</h1>
      <h2 className="2">hello</h2>
    </div>
    <div>test1</div>
  </React.Fragment>
);

// React 활동영역 선정 id = root;
// React 에게 활동영역 알려주고 => reactRoot
const rootNode = document.getElementById("root");
const reactRoot = createRoot(rootNode!);

// 활동영역에 작성한 엘리먼트 던지기
reactRoot.render(jsxElement);

// npm start 하면 화면에 출력
